import lds_driver
import piconzero as pz
import time
import signal
import sys

# Initialize the lidar
port = "/dev/ttyUSB0"
baud_rate = 230400
mode = 360  # Full 360-degree scan
laser = lds_driver.LFCDLaser(port, baud_rate, mode)

# Initialize the Picon Zero
pz.init()

# Define the servo pin for steering
steering_pin = 1
pz.setOutputConfig(steering_pin, 2)

# Center the steering
steering_center = 93
pz.setOutput(steering_pin, steering_center)

# Define speed range
min_speed = 30
max_speed = 100
initial_speed = 35

# Maximum distances for scaling
max_distance_front = 2.5  # meters
max_distance_side = 1.2   # meters

def get_max_distance(distances, start, end):
    return max(distances[start:end])

def scale_speed(distance, max_distance):
    # Scale speed based on distance and return as integer
    return int(min_speed + (max_speed - min_speed) * (distance / max_distance))

def signal_handler(sig, frame):
    print('Stopping the car...')
    pz.stop()
    pz.setOutput(steering_pin, steering_center)
    pz.cleanup()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

while True:
    try:
        distances = laser.poll()
        distances = [round(distance, 3) for distance in distances]

        # Exclude the backside distances
        front_left = get_max_distance(distances, 113, 158)
        front = get_max_distance(distances, 158, 203)
        front_right = get_max_distance(distances, 203, 248)
        left = get_max_distance(distances, 68, 113)
        right = get_max_distance(distances, 248, 293)

        # Scale speed based on front distance
        speed = scale_speed(front, max_distance_front)
        
        # Stop the car if the front distance is too short
        if front < 0.3 and front > 0:  # Stop if an obstacle is closer than 0.3 meters
            pz.reverse (128)
            time.sleep(0.3) 
            print("Obstacle too close! Stopping the car.")
        else:
            # Determine the direction to move
            if front > front_left and front > front_right:
                # Move forward
                new_steering_value = steering_center
                pz.forward(speed)
                print("Moving forward")
            elif front_left > front_right and front_left > right:
                # Turn left
                new_steering_value = max(steering_center - 40, 33)
                pz.forward(speed)
                print("Turning left")
            elif front_right > front_left and front_right > left:
                # Turn right
                new_steering_value = min(steering_center + 40, 160)
                pz.forward(speed)
                print("Turning right")
            elif right > left:
                # Steer to the right with max speed
                new_steering_value = 160
                pz.forward(128)
                print("Steering to the right with max speed")
                time.sleep(0.5) 
            elif left > right:
                # Steer to the left with max speed
                new_steering_value = 30
                pz.forward(128)
                print("Steering to the left with max speed")
                time.sleep(0.3) 
            else:
                # Default to moving forward
                new_steering_value = steering_center
                pz.forward(speed)
                print("Default to moving forward")

            pz.setOutput(steering_pin, new_steering_value)

        print(f"Max Distances - Front Left: {front_left}, Front: {front}, Front Right: {front_right}, Left: {left}, Right: {right}")
        print(f"Steering: {new_steering_value}")
        print(f"Speed: {speed}")

    except Exception as e:
        print(f"Error: {e}")
    
    time.sleep(0.1)  # Adjust the sleep time as necessary
