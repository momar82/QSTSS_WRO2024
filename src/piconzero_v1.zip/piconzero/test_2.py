import lds_driver
import piconzero as pz
import time

# Initialize the Picon Zero
pz.init()

# Define the servo pin for steering
steering_pin = 1
pz.setOutputConfig(steering_pin, 2)

# Center the steering
steering_center = 93
pz.setOutput(steering_pin, steering_center)

# Define speed for moving forward
initial_speed = 35
pz.forward(initial_speed)

# Initialize the LiDAR
port = "/dev/ttyUSB0"
baud_rate = 230400
mode = 360
laser = lds_driver.LFCDLaser(port, baud_rate, mode)

# PID controller for steering
steering_pid = PID(Kp=1.0, Ki=0.0, Kd=0.1)

def get_max_distance(distances, start, end):
    return max(distances[start:end])

while True:
    distances = laser.poll()
    distances = [round(distance, 3) for distance in distances]

    # Exclude the backside distances
    front_left = get_max_distance(distances, 113, 158)
    front = get_max_distance(distances, 158, 203)
    front_right = get_max_distance(distances, 203, 248)
    left = get_max_distance(distances, 68, 113)
    right = get_max_distance(distances, 248, 293)

    # Determine the direction to steer
    if front > front_left and front > front_right:
        steering_value = steering_center
    elif front_left > front_right:
        steering_value = steering_center - 20  # Turn left
    else:
        steering_value = steering_center + 20  # Turn right

    # Apply PID control to smooth the steering
    steering_adjustment = steering_pid.compute(steering_center, steering_value)
    pz.setOutput(steering_pin, steering_center + steering_adjustment)

    # Move forward
    pz.forward(initial_speed)
    time.sleep(0.1)  # Adjust the sleep time as necessary

# Clean up the Picon Zero
pz.cleanup()
