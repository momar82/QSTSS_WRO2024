import piconzero as pz
import time
import lds_driver

# Initialize the Picon Zero
pz.init()

# Define constants
speed = 50  # Speed set to 50
tilt_left = 25
tilt_center = 93
tilt_right = 170
front_threshold = 30  # Distance in cm for obstacle detection
corner_threshold = 10  # Close range to detect corners
turns = 3  # Number of full turns to execute

# Set the servo pin for tilt (assuming pin 1 for tilt)
tilt_pin = 1
pz.setOutputConfig(tilt_pin, 2)  # Set to Servo mode
pz.setOutput(tilt_pin, tilt_center)  # Center the tilt initially

# Initialize the LiDAR sensor
port = "/dev/ttyUSB0"
baud_rate = 230400
mode = 360  # Assuming 360-degree mode
laser = lds_driver.LFCDLaser(port, baud_rate, mode)

# Function to fetch LiDAR sensor data
def read_lidar_distances():
    try:
        distances = laser.poll()  # Get distance readings
        distances = [round(distance, 3) for distance in distances]  # Round distances for readability
        return distances
    except Exception as e:
        print(f"LiDAR reading error: {e}")
        return [100] * 35  # Return default safe distances if error occurs

def process_lidar_data(lidar_readings):
    # Extract relevant distances from the LiDAR readings
    front_distances = lidar_readings[15:20]  # Front distances (assumed range in list)
    left_distances = lidar_readings[0:15]    # Left distances (first part of list)
    right_distances = lidar_readings[20:35]  # Right distances (last part of list)

    # Average the distances for each direction
    front_distance = sum(front_distances) / len(front_distances)
    left_distance = sum(left_distances) / len(left_distances)
    right_distance = sum(right_distances) / len(right_distances)

    return front_distance, left_distance, right_distance

# Function to perform a full turn
def perform_full_turn(direction):
    if direction == "right":
        pz.spinRight(speed)
        pz.setOutput(tilt_pin, tilt_right)
        print("Turning right...")
    else:  # Assume left if not right
        pz.spinLeft(speed)
        pz.setOutput(tilt_pin, tilt_left)
        print("Turning left...")
    
    time.sleep(1)  # Adjust the time as necessary for a full turn
    pz.stop()  # Stop after turning
    time.sleep(0.5)  # Pause before the next action

# Function to move around the square while avoiding obstacles
def navigate_square(turns):
    for _ in range(turns):
        # Start with moving forward
        while True:
            lidar_readings = read_lidar_distances()  # Fetch LiDAR sensor data
            front_distance, left_distance, right_distance = process_lidar_data(lidar_readings)

            # Print out the distances to see what the LiDAR is reading
            print(f"Front Distance: {front_distance}, Left Distance: {left_distance}, Right Distance: {right_distance}")

            if front_distance > front_threshold:
                # Scenario 1: Clear path, move forward
                pz.forward(speed)
                pz.setOutput(tilt_pin, tilt_center)  # Keep centered
                print("Moving forward...")
                time.sleep(1)  # Move forward for a brief period
            else:
                # Stop moving forward when an obstacle is detected
                pz.stop()
                print("Obstacle detected ahead. Stopping and turning...")

                if right_distance > corner_threshold:
                    # Turn right if the right side is clear
                    perform_full_turn("right")
                    break  # Break out of the loop after turning right
                elif left_distance > corner_threshold:
                    # Turn left if the left side is clear
                    perform_full_turn("left")
                    break  # Break out of the loop after turning left
                else:
                    # Stop if no clear path is available
                    print("No clear path, stopping.")
                    pz.stop()
                    return

# Main loop
try:
    navigate_square(turns)
    print("Completed 3 full turns around the square.")

    # Stop the car after completing the turns
    pz.stop()

except KeyboardInterrupt:
    print("Program stopped by user.")

finally:
    pz.cleanup()
