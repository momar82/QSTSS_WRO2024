import piconzero as pz
import time

# Initialize Picon Zero
pz.init()

# Define constants
speed = 90  # Speed for moving forward and turning
tilt_right = 155
tilt_center = 93
tilt_pin = 1

# Set the servo pin for tilt (assuming pin 1 for tilt)
pz.setOutputConfig(tilt_pin, 2)  # Set to Servo mode
pz.setOutput(tilt_pin, tilt_center)  # Center the tilt initially
time.sleep(0.3)  # Adjust this time as necessary for a right turn


# Main function to complete 3 laps
def complete_laps():
    pz.forward(speed)
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_right)
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_center)  # Re-center the tilt after turning
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_right)
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_center)  # Re-center the tilt after turning
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_right)
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_center)  # Re-center the tilt after turning
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_right)
    time.sleep(1)  # Adjust this time as necessary for a right turn
    pz.setOutput(tilt_pin, tilt_center)  # Re-center the tilt after turning
    time.sleep(0.5)  # Adjust this time as necessary for a right turn
    pz.reverse(100)
    time.sleep(0.3)  # Adjust this time as necessary for a right turn

    pz.stop()

    print("Completed 3 laps.")

# Main loop
try:
    complete_laps()
    pz.stop()
    complete_laps()
    pz.stop()
    complete_laps()
    pz.stop()

except KeyboardInterrupt:
    print("Program stopped by user.")

finally:
    pz.cleanup()
