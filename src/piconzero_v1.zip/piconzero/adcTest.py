#! /usr/bin/env python

# GNU GPL V3
# Test code for 4tronix Picon Zero

import piconzero as pz, time, collections

pz.init()
pz.setInputConfig(0, 1)     # set input 0 to analog input
pz.setInputConfig(2, 1)     # set input 2 to analog input

# Function to convert analog value to distance
def analog_to_distance(analog_value):
    # Convert the analog value to voltage (assuming 5V reference)
    voltage = analog_value * (5.0 / 255.0)
    # Convert voltage to distance (based on sensor's datasheet)
    distance = voltage / 0.0098  # 9.8mV per cm
    return distance

# Moving average filter
def moving_average(data, window_size):
    return sum(list(data)[-window_size:]) / window_size

window_size = 5
readings0 = collections.deque(maxlen=window_size)
readings2 = collections.deque(maxlen=window_size)

try:
    while True:
        ana0 = pz.readInput(0)
        ana2 = pz.readInput(2)
        readings0.append(ana0)
        readings2.append(ana2)
        smoothed_value0 = moving_average(readings0, window_size)
        smoothed_value2 = moving_average(readings2, window_size)
        distance0 = analog_to_distance(smoothed_value0)
        distance2 = analog_to_distance(smoothed_value2)
        print(f"Distance0: {distance0:.2f} cm, Distance2: {distance2:.2f} cm")
        time.sleep(0.25)
except KeyboardInterrupt:
    print("Program interrupted")
finally:
    pz.cleanup()
