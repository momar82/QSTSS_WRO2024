import serial
import struct
import time

class LFCDLaser:
    def __init__(self, port, baud_rate):
        self.port = port
        self.baud_rate = baud_rate
        try:
            self.serial = serial.Serial(port, baud_rate, timeout=2)
            print(f"Opened serial port {port} at {baud_rate} baud.")
        except serial.SerialException as e:
            print(f"Failed to open serial port: {e}")
            raise
        self.shutting_down = False

    def start_motor(self):
        self.serial.write(b'b')
        print("Motor started.")

    def stop_motor(self):
        self.serial.write(b'e')
        print("Motor stopped.")

    def poll(self):
        distances = [0] * 360
        start_count = 0
        got_scan = False
        raw_bytes = bytearray(2520)
        good_sets = 0
        motor_speed = 0
        rpms = 0

        time.sleep(2)  # Add a delay to ensure the device is ready

        while not self.shutting_down and not got_scan:
            try:
                self.serial.reset_input_buffer()  # Flush input buffer
                self.serial.readinto(raw_bytes[start_count:start_count+1])
                print(f"Read byte: {raw_bytes[start_count]:02X}")

                if start_count == 0:
                    if raw_bytes[start_count] == 0xFA:
                        start_count = 1
                elif start_count == 1:
                    if raw_bytes[start_count] == 0xA0:
                        start_count = 0
                        got_scan = True
                        self.serial.readinto(raw_bytes[2:2520])
                        print("Start sequence found. Reading data...")

                        for i in range(0, len(raw_bytes), 42):
                            if raw_bytes[i] == 0xFA and raw_bytes[i + 1] == (0xA0 + i // 42):
                                good_sets += 1
                                motor_speed += (raw_bytes[i + 3] << 8) + raw_bytes[i + 2]
                                rpms = ((raw_bytes[i + 3] << 8) | raw_bytes[i + 2]) / 10

                                for j in range(i + 4, i + 40, 6):
                                    index = 6 * (i // 42) + (j - 4 - i) // 6
                                    byte0 = raw_bytes[j]
                                    byte1 = raw_bytes[j + 1]
                                    byte2 = raw_bytes[j + 2]
                                    byte3 = raw_bytes[j + 3]
                                    intensity = (byte1 << 8) + byte0
                                    range_mm = (byte3 << 8) + byte2
                                    distance = range_mm / 1000.0
                                    distances[359 - index] = distance
                                    print(f"r[{359 - index}]={distance:.3f},")
                    else:
                        start_count = 0
            except serial.SerialException as e:
                print(f"Serial error: {e}")
                break

    def calculate_averages(self, distances):
        averaged_distances = []
        for i in range(0, 360, 10):
            avg = round(sum(distances[i:i + 10]) / 10, 2)
            averaged_distances.append(avg)
        return averaged_distances

    def close(self):
        self.shutting_down = True
        self.stop_motor()
        self.serial.close()
        print("Serial port closed.")

if __name__ == "__main__":
    port = "/dev/ttyUSB0"
    baud_rate = 230400

    try:
        laser = LFCDLaser(port, baud_rate)
        laser.start_motor()
        laser.poll()
    except KeyboardInterrupt:
        laser.close()
    except Exception as e:
        print(f"An exception occurred: {e}")
        laser.close()
