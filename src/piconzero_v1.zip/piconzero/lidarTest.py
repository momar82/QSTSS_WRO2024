import serial
import struct

class LFCDLaser:
    def __init__(self, port, baud_rate):
        self.port = port
        self.baud_rate = baud_rate
        self.serial = serial.Serial(port, baud_rate)
        self.shutting_down = False

    def start_motor(self):
        self.serial.write(b'b')

    def stop_motor(self):
        self.serial.write(b'e')

    def poll(self):
        while not self.shutting_down:
            raw_bytes = self.serial.read(2520)
            if raw_bytes[0] == 0xFA and raw_bytes[1] == 0xA0:
                
                for i in range(0, len(raw_bytes), 42):
                    if raw_bytes[i] == 0xFA and raw_bytes[i+1] == (0xA0 + i // 42):
                        
                        for j in range(i+4, i+40, 6):
                            
                            index = 6 * (i // 42) + (j - 4 - i) // 6
                            byte0, byte1, byte2, byte3 = raw_bytes[j:j+4]
                            intensity = (byte1 << 8) + byte0
                            range_mm = (byte3 << 8) + byte2
                            distance = range_mm / 1000.0
                            print(f"r[{359-index}]={distance:.3f}m")

    def close(self):
        self.shutting_down = True
        self.stop_motor()
        self.serial.close()

if __name__ == "__main__":
    port = "/dev/ttyUSB0"
    baud_rate = 230400

    laser = LFCDLaser(port, baud_rate)
    try:
        laser.start_motor()
        laser.poll()
    except KeyboardInterrupt:
        laser.close()
    except Exception as e:
        print(f"An exception occurred: {e}")
        laser.close()