import piconzero as pz
import time

# Initialize the Picon Zero
pz.init()

# Define the servo pin for tilt
tilt_pin = 1

# Set the servo to Servo mode
pz.setOutputConfig(tilt_pin, 2)

# Center the tilt to 90 degrees
tilt_center = 93
pz.setOutput(tilt_pin, tilt_center)
print(f"Tilt centered at {tilt_center} degrees")

# Define speed for moving forward
speed = 25  # Adjust speed as necessary

# Move forward for 5 seconds
pz.forward(speed)
print("Moving forward...")
time.sleep(5)  # Move forward for 5 seconds

# Stop the car
pz.stop()
print("Stopped.")

# Clean up the Picon Zero
pz.cleanup()
