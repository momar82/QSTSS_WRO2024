import lds_driver

def main():
    port = "/dev/ttyUSB0"
    baud_rate = 230400

    laser = lds_driver.LFCDLaser(port, baud_rate)
    while True:
        output = laser.poll()
        # Parse the output into a list of distances
        readings = output.split(',')
        distances = []
        for reading in readings:
            if reading:
                index, value = reading.split('=')
                distances.append(float(value))
        
        # Print the distances array
        print(distances)

if __name__ == "__main__":
    main()
