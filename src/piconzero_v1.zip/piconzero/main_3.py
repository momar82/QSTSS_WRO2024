import lds_driver

def main():
    port = "/dev/ttyUSB0"
    baud_rate = 230400
    mode = 360  # Change this to 36 or 10 as needed

    laser = lds_driver.LFCDLaser(port, baud_rate, mode)
    
    while True:
        distances = laser.poll()
        distances = [round(distance, 3) for distance in distances]
        #print(f"Distances (mode {mode}):", distances)
        print(f" ", distances)
if __name__ == "__main__":
    main()
