#!/usr/bin/env python3

# Picon Zero Servo Test
# Use arrow keys to move 2 servos on outputs 0 and 1 for Pan and Tilt
# Use G and H to open and close the Gripper arm
# Press Ctrl-C to stop

import piconzero as pz
import time
import sys
import tty
import termios

#======================================================================
# Reading single character by forcing stdin to raw mode

def readchar():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    if ch == '\x03':
        raise KeyboardInterrupt
    return ch

def readkey(getchar_fn=None):
    getchar = getchar_fn or readchar
    c1 = getchar()
    if ord(c1) != 0x1b:
        return c1
    c2 = getchar()
    if ord(c2) != 0x5b:
        return c1
    c3 = getchar()
    return chr(0x10 + ord(c3) - 65)  # 16=Up, 17=Down, 18=Right, 19=Left arrows

# End of single character reading
#======================================================================

speed = 60

print("Tests the servos by using the arrow keys to control")
print("Press <space> key to centre")
print("Press Ctrl-C to end")
print()

# Define which pins are the servos

tilt = 1


pz.init()

# Set output mode to Servo

pz.setOutputConfig(tilt, 2)


# Centre all servos

tiltVal = 90

pz.setOutput(tilt, tiltVal)

pz.forward(30)
# main loop
try:
    while True:
        keyp = readkey()
        if keyp == 's' or ord(keyp) == 18:
            tiltVal = max(0, tiltVal + 5)
            print('Right', tiltVal)
        elif keyp == 'a' or ord(keyp) == 19:
            tiltVal = min(180, tiltVal - 5)
            print('Left', tiltVal)
        elif keyp == ' ':
            tiltVal = 90
            print('Centre')
        elif ord(keyp) == 3:
            break
        pz.setOutput(tilt, tiltVal)

except KeyboardInterrupt:
    print()

finally:
    pz.cleanup()
